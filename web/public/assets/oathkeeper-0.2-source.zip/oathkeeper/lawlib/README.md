# lawlib

The planned community library of reviewed legal definitions and formalized rules.
The first [Seattle module](us/wa/seattle/README.md) now contains real-authority
formalizations with pinned source artifacts and five executable reconstructions
of issues in an actual case. These are machine-assisted and awaiting independent
legal/formal review. They are not a complete or certified corpus. The original
fictional tutorial remains in `examples`.

Start with US material under `us/`; use stable namespaces such as `us.federal`,
`us.ca`, and `us.ca.san-francisco` when real reviewed modules are introduced.
Names do not themselves establish jurisdiction relationships: packages must
declare edges explicitly. Other systems can add independent roots without
changing the kernel. Private covenant contexts must identify their private
authority and their conditions of enforceability.

Every proposed module should include:

1. Primary authority, retrieval timestamp, source bytes or a reproducible source
   reference, SHA-256, licensing/public-domain assessment, and pinpoint citation.
2. Jurisdiction, legal effective interval, recording timestamp, immutable rule
   version, and a package snapshot/version.
3. An explanation mapping each legal phrase to formal premises and conclusions,
   including the scope, omitted requirements, exceptions, and interpretation.
4. Clearly identified case axioms and subjective oracle functions; no subjective
   assessment may be hidden as a deterministic fact to improve the score.
5. Positive and negative example cases, time-boundary checks, counterarguments,
   and a discussion of potentially conflicting authorities.
6. Separate legal and formalization review. Record reviewer roles and unresolved
   disputes, without implying review has occurred when it has not.

Keep uncertain interpretations as separately identified proposals. Do not silently
merge incompatible authorities or use child jurisdiction depth to settle them.
The contribution template is metadata for human review, not a kernel import.

The intended path to a mathlib-scale corpus is a small reviewed vocabulary,
well-scoped statutory modules, reusable legal definitions, and explicit records
of interpretation. Corpus expansion should follow review capacity rather than
automatically treating extracted text as settled formal law.
