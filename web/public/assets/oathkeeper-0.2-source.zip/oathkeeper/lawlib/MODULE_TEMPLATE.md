# Module proposal: <namespace>

Status: proposed / in review / reviewed / superseded

Package version:
Jurisdiction and applicable parent contexts:
Primary authority and pinpoint citations:
Source URL and retrieval timestamp:
Source SHA-256 and source rights:
Legal effective interval:
Recorded-at timestamp:
Rule IDs and versions:

## Interpretation and scope

State exactly what is formalized, what is omitted, and why the premises match
the legal text. Explain jurisdiction edges and authority relationships.

## Facts, oracles, and evidence

List trusted case axioms, subjective functions, permitted providers and versions,
questions, evidence references, confidence thresholds, and abstention behavior.

## Verification and counterexamples

Link executable proof bundles, rejected examples, temporal boundary cases,
counterarguments, and conflict analysis. Record the kernel/language version.

## Review record

Legal reviewer:
Formalization reviewer:
Review date and immutable review reference:
Unresolved questions:

Review records are maintained by contributors; the v0.1 kernel does not verify
reviewer identity or signatures.
