# Roadmap

## 0.1 — executable foundation (implemented)

- Open TOML/JSON ground proof language and Rust verifier.
- Explicit positive/negative claims and ordered rule applications.
- Jurisdiction applicability DAG and bitemporal rule snapshots.
- Frozen probabilistic oracle outputs and request-bound provider agreements.
- Dependency reports, bundle fingerprints, normalized oracle-count score.
- CLI, native Python bindings, fictional US/HOA example, fixed-context RL example.
- Tests, CI, Apache license, and legal library contribution protocol.

## 0.2 — real law and scoped precedent (implemented)

- Reusable law modules and separate case files; typed symbol/integer parameters.
- Explicit ground substitutions and checked integer comparisons.
- Authorities, holding/text roles, explicit scope premises, forum/time assessments,
  and treatment/review status in dependency reports.
- Sourced fact classifications separating record facts, judicial findings, and
  scope assumptions.
- Seattle Ordinance 120573, Long, and Timbs: nine rules and five historical proofs.
- Pinned source snapshots, representation-aware replay, source auditing, and
  explicit incomplete coverage inventory.

## Next — language and provenance

- Richer typed terms, dates, quantities, parties, and quantified reasoning.
- Versioned module imports and a package lock/registry format.
- Cross-implementation canonical serialization and signed oracle attestations.
- Authenticated evidence ingestion, source-byte verification, and replay tools.
- Resource limits and stable structured error codes for hosted evaluation.
- Proof search outside the kernel; editor tooling and a readable expression DSL.

## Legal library

- Establish legal and formalization review with immutable provenance.
- Add a small, reviewed US module before scaling a shared definitions library.
- Represent exceptions, preemption, burdens, and disputed interpretations with
  explicit semantics and independently tested proof rules.
- Add counterproof/consistency analysis, authority relations, and case-law models.
- Introduce other legal systems with contributors competent in those systems;
  encode cross-border choice of law explicitly.

## Training and institutional use

- Curate immutable proof tasks with audited assumptions and leakage controls.
- Evaluate adversarial proof generation and oracle dependence separately.
- Research calibrated uncertainty without treating confidence as a theorem.
- Explore court pilots only with agreed corpus, authenticated oracle procedures,
  procedural safeguards, contestability, and qualified institutional partners.

These are goals, not claims of implemented functionality or court readiness.
