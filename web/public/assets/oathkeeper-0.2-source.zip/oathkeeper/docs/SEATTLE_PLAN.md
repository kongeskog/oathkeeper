# Toward comprehensive Seattle formalization

The target is all law applicable in Seattle, with a separately measurable
inventory of Seattle's own enacted law. Those are different scopes. Seattle's
Municipal Code is a classified compilation of general and permanent ordinances;
it is not the complete set of potentially relevant authorities. The
[City Clerk's code/charter guide](https://www.seattle.gov/city-clerk/legislation-and-research/seattle-municipal-code-and-city-charter)
and [legislative research guide](https://www.seattle.gov/city-clerk/legislation-and-research/legislative-research-guide)
are the starting points for source inventory.

## Inventory before claiming completeness

Record the code supplement/version and every title, chapter, section, subsection,
definition, cross-reference, amendment, and effective interval. Add the City
Charter, uncodified ordinances, emergency provisions, and applicable agency rules.
Maintain explicit links to relevant Washington/federal constitutions, statutes,
regulations, and judicial decisions; add county and tribal authority where
applicable rather than treating geography as an automatic hierarchy.

Each provision should have a stable ID and one of these coverage states:

```text
discovered -> source_pinned -> interpreted -> formalized -> tested -> reviewed
                                                         -> disputed
reviewed -> superseded / repealed / review_required
```

An English text import is `source_pinned`, not `formalized`. A formalized rule is
not `reviewed` until separate legal and technical review is recorded. Treat
coverage of text, executable rules, exceptions, and reviewed rules as separate
metrics. Until the provision inventory has a reliable denominator, report counts
and explicit omissions rather than a percentage.

## Authoring unit

Use reusable JSON `LawModule` files containing rules and authorities, and separate
JSON `CaseFile` files containing case inputs and proofs. Current composition is
one module plus one case; transitive module imports and a module package lock are
not implemented yet. Shared sources are pinned with representation-aware hashes.
Module/rule IDs and versions are stable; case-specific substitutions must not be
embedded in reusable rule definitions.

Every rule needs a mapping from the legal text to its premises, exceptions, and
conclusion. Every case holding needs the court, majority/holding identification,
pinpoint, scope, forum, and legal-time-specific treatment assessment. Do not turn
a party argument, trial-court outcome later reversed, syllabus, or concurrence
into an operative majority holding. Record alternatives and disputes explicitly.

Historical case reconstructions and application to a new record are different
tasks. The first can use court-reported findings with provenance. The second
needs its own facts and any necessary oracle assessments; it cannot inherit the
original litigant's factual or evaluative findings.

## Language work required for full coverage

Implemented in 0.2: symbol/integer terms, typed rule parameters, explicit ground
substitutions, checked integer comparisons, authority-backed rules, explicit scope
premises, forum/time treatment gates, and fact provenance.

Still required for faithful treatment of many Seattle provisions:

- Rich typed entities, relationships, quantification, and checked unification.
- Exact money and units, dates, durations, calendar deadlines, and business days.
- Obligations, permissions, prohibitions, remedies, parties, burdens, and standards
  of proof, with written semantics rather than suggestive predicate names.
- Exceptions and defeasibility, preemption, competing holdings, partial overruling,
  severability, and temporal amendments/retractions.
- Structured geographic/zoning applicability and incorporation by reference.
- Transitive imports, package locks, canonical signatures, and authenticated
  evidence/oracle ingestion.

Opaque predicates can represent an externally established judgment, but they do
not replace these semantics. An oracle must not be a way to hide an entire
unformalized section while claiming corpus completeness.

## Concrete current baseline

`lawlib/us/wa/seattle` pins three real authorities, nine reusable rules, and five
actual Long case reconstructions. It encodes selected parking, excessive-fines,
and homestead issues. It does not certify subsequent treatment through 2026 or
complete coverage of any SMC chapter. The legal snapshot is August 2021.

Expand one bounded chapter at a time, starting with Chapter 11.30 procedure and
the remaining branches of SMC 11.72.440 so the present module's statutory
dependencies become explicit. Then select further chapters, build real
adjudicated examples and boundary cases, and track progress in the inventory.

For RL, freeze the module, evidence, agreements, authority assessments, query,
and evaluation policy. Whether a court finding is an allowed input depends on
the task: a model asked to determine disproportionality must not receive the
court's final disproportionality finding as an undisclosed input. Historical
derivation reconstruction can use it, with that dependency visible in the report.
