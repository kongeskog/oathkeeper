# Verifiable rewards

The useful training target is an explicit legal derivation whose assumptions are
visible. Kernel acceptance alone cannot establish the real-world truth of a
model-generated legal theory.

The real Seattle historical proofs can be normalized for this evaluator with
`oathkeeper normalize-case <module.json> <case.json>`. These tasks reconstruct
reasoning from a court record. The final disproportionality assessment is a
visible `judicial_finding` input in the Long excessive-fines reconstruction. Do
not reuse that input when evaluating a model's ability to decide disproportionality
itself: it would disclose the target judgment. For new cases, freeze appropriate
independent evidence and agreed oracle outputs instead of transferring Long's
findings to a new litigant.

An RL environment must own and freeze the laws, jurisdiction graph, case facts,
oracle policy and attestations, time context, goal, root ID, and language/kernel
versions. The model submits **only the proof array**. Allowing it to edit the
trusted context would let it invent a rule or move an opinion into a fact.

`examples/evaluate_proof.py` implements that boundary. It replaces only `proof`
in a host-controlled JSON bundle and invokes the native Rust verifier. By
default it accepts zero-oracle proofs; an explicit `allow_oracles=True` option
accepts conditional proofs under the already-frozen agreements. It returns a
binary reward and, for accepted proofs, the full dependency report. An invalid
host context is a setup error, not a negative model reward.

```sh
# Install the Python extension first; see README.
cargo run -- normalize examples/hoa.oath > /tmp/oathkeeper-case.json
python -c 'import json; from pathlib import Path; b=json.loads(Path("/tmp/oathkeeper-case.json").read_text()); Path("/tmp/oathkeeper-proof.json").write_text(json.dumps(b["proof"]))'
python examples/evaluate_proof.py /tmp/oathkeeper-case.json /tmp/oathkeeper-proof.json --allow-oracles
```

The example receives reward 1 only with conditional proofs enabled, because its
goal depends on the color assessment. Malformed or invalid submitted proofs
receive reward 0. Oracle confidence does not become the reward. Verifiability is
a diagnostic and possible additional objective after inputs are reviewed; it is
not a truth label or a calibrated confidence score. A zero-oracle derivation can
still depend on false case axioms or an incorrect legal encoding.

For experiments, pin a dataset commit and raw context hash in addition to the
kernel snapshot fingerprint; record all accepted proof reports. Separate source
formalization evaluation, oracle calibration, and proof construction evaluation.
Train/test splitting should isolate related cases and legal provisions to avoid
memorizing proof templates. Services should impose input and resource limits
before invoking this in-process research kernel.
