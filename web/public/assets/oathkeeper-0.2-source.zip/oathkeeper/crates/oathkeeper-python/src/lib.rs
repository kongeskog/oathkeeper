use pyo3::{exceptions::PyValueError, prelude::*};

/// Return a deterministic JSON report, or raise ValueError on any invalid input.
#[pyfunction]
#[pyo3(signature = (source, format="oath"))]
fn verify(source: &str, format: &str) -> PyResult<String> {
    let report = oathkeeper_core::verify_text(source, format)
        .map_err(|error| PyValueError::new_err(error.to_string()))?;
    serde_json::to_string(&report).map_err(|error| PyValueError::new_err(error.to_string()))
}

#[pyfunction]
fn verify_case(module_json: &str, case_json: &str) -> PyResult<String> {
    let bundle = oathkeeper_core::assemble_case(module_json, case_json)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    let report =
        oathkeeper_core::verify(&bundle).map_err(|e| PyValueError::new_err(e.to_string()))?;
    serde_json::to_string(&report).map_err(|e| PyValueError::new_err(e.to_string()))
}

#[pymodule]
fn oathkeeper(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(verify, module)?)?;
    module.add_function(wrap_pyfunction!(verify_case, module)?)?;
    module.add("__version__", env!("CARGO_PKG_VERSION"))?;
    Ok(())
}
