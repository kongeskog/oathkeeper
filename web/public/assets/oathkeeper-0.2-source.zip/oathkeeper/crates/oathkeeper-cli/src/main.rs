use oathkeeper_core::{assemble_case, parse, verify};
use std::{env, fs, process::ExitCode};

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().skip(1).collect();
    let bundle = if args.len() == 3 && matches!(args[0].as_str(), "verify-case" | "normalize-case")
    {
        assemble_case(
            &fs::read_to_string(&args[1])?,
            &fs::read_to_string(&args[2])?,
        )?
    } else if args.len() == 2 && matches!(args[0].as_str(), "verify" | "normalize") {
        let input = fs::read_to_string(&args[1])?;
        let format = if args[1].ends_with(".json") {
            "json"
        } else {
            "oath"
        };
        parse(&input, format)?
    } else {
        return Err("usage: oathkeeper <verify|normalize> <bundle.oath|bundle.json>\n       oathkeeper <verify-case|normalize-case> <module.json> <case.json>".into());
    };
    // Normalization also checks the proof: invalid bundles never look accepted.
    let report = verify(&bundle)?;
    let output = if args[0].starts_with("verify") {
        serde_json::to_string_pretty(&report)?
    } else {
        serde_json::to_string_pretty(&bundle)?
    };
    println!("{output}");
    Ok(())
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("oathkeeper: {error}");
            ExitCode::FAILURE
        }
    }
}
