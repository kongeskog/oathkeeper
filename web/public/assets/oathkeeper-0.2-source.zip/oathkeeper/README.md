# Oathkeeper

**An open specification and Rust kernel for verifiable legal proofs.**

Oathkeeper aims to make legal reasoning inspectable and machine-checkable, with
the long-term role that Lean and mathlib play in mathematics. Subjective judgments
remain explicit oracle assumptions. A proof establishes what follows from its
supplied formalization, facts, and agreed oracle outputs.

This repository contains a working **0.2 research prototype**: parameterized legal
rules, a deterministic Rust proof checker, CLI, native Python extension, and a
[real Seattle law module](lawlib/us/wa/seattle/README.md) built from an enacted
ordinance and two court decisions. Nine reusable rules and five historical case
proofs are source-pinned and executable. The formalization awaits independent
review; it is not a complete legal corpus or a general legal reasoner.

```sh
cargo run -- verify-case lawlib/us/wa/seattle/parking.module.json lawlib/us/wa/seattle/cases/long-excessive-fines.case.json
python tools/audit_lawlib.py
# The original fictional oracle demo is retained as a language tutorial:
cargo run -- verify examples/hoa.oath
cargo run -- normalize examples/hoa.oath > /tmp/oathkeeper-case.json
cargo test --workspace
```

The fictional tutorial checks a six-step proof across a federal → state → city →
HOA applicability chain. Its result includes:

```json
{
  "status": "verified_conditional",
  "oracle_assumptions": ["color-assessment-1"],
  "oracle_count": 1,
  "verifiability": 0.5,
  "score_version": "oracle-count-v1"
}
```

Rules have immutable version identities, legal validity intervals, knowledge
timestamps, and source citations and hashes. Queries select both a legal time and
a knowledge cutoff. Jurisdictions form an explicit applicability DAG; an HOA is a
private covenant context, not another level of sovereign government. Inheritance
collects applicable rules. Preemption, authority, exceptions, and choice of law
require explicit formalization; geographic depth never implies override power.

An oracle is a subjective boolean function over identified evidence, implemented
outside the kernel by a human panel or classifier. Its frozen attestation includes
the proposition, question, provider and version, confidence, evidence digest, and
timestamp. The checker enforces the supplied agreement before using the result.
Confidence is a reported model/panel value, not a calibrated legal probability.

The built-in normalized score is **`1 / (1 + N)`**, where `N` is the number of
distinct attestation IDs in the goal's proof dependencies. Scores are 1, ½, ⅓, …;
shared dependencies count once. Facts and rule dependencies are reported too.
The score measures oracle dependence, not truth, legal validity, evidence quality,
or coverage. Moving an opinion into a fact can game it, so trusted input review is
part of the design. See [the specification](docs/SPEC.md).

For Python (Python 3.10+ and a Rust toolchain):

```sh
python -m venv .venv
. .venv/bin/activate
pip install 'maturin>=1.7,<2'
maturin develop
python -m unittest discover -s python/tests
```

```python
import json
from pathlib import Path
import oathkeeper

report = json.loads(oathkeeper.verify(Path("examples/hoa.oath").read_text()))
print(report["verifiability"])
# Invalid proofs raise ValueError. JSON transport: verify(text, "json").
```

The Seattle module formalizes selected holdings of *City of Seattle v. Long*
(Washington Supreme Court, 2021), the federal incorporation holding in *Timbs v.
Indiana* (2019), and portions of SMC 11.72.440 from Ordinance 120573. Its historical
proofs expose the court's recorded judgments as sourced inputs. A score of 1.0
for such a reconstruction does not independently establish those judgments.
The module records its August 2021 legal snapshot and unreviewed status.

The 0.2 language adds typed symbol/integer parameters, explicit substitutions,
checked integer comparisons, first-class authorities, holding scope conditions,
forum/time-specific treatment assessments, and provenance for facts. A case file
cannot replace its shared module's rules. See the
[Seattle coverage plan](docs/SEATTLE_PLAN.md) for the inventory and language work
needed before claiming citywide completeness.

The kernel never calls a model, accesses the network, reads evidence files, or
silently resolves legal conflicts. Source/evidence hashes are provenance references;
the kernel checks their format, not the referenced bytes or authenticity. The
separate lawlib auditor verifies pinned local source bytes and references. A verified
derivation can rest on an incorrect law encoding or false evidence. Court use
would require independent legal review, authenticated attestations, accepted
procedures, and a much richer logic than this prototype provides.

- [0.2 language specification](docs/SPEC-0.2.md) · [0.1 specification](docs/SPEC.md)
- [Architecture and trust boundaries](docs/ARCHITECTURE.md)
- [RL evaluation with pinned context](docs/TRAINING.md)
- [Legal library and review process](lawlib/README.md)
- [Roadmap](docs/ROADMAP.md) · [Contributing](CONTRIBUTING.md)

Licensed under [Apache 2.0](LICENSE). No network service or account is required.
