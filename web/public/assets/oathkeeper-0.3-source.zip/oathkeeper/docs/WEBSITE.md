# Oathkeeper application

The private application is deployed at:

https://oathkeeper-field-guide.rainy-puppy-3202.chatgpt.site

Website source checkout: `/workspace/sites/oathkeeper-guide`.
The application uses React, TypeScript, Tailwind CSS 4, Vite, and official
shadcn/ui components, with a separate Sites source repository and owner-private
hosting. Its twenty data/React interaction tests and production build pass.
Local Chromium checks cover all 49 routes, desktop/mobile navigation, deep
links, filter persistence, proof dependencies, and actual source hashing.

The workspace includes:

- A concise overview and persistent navigation with Ctrl/Cmd+K search.
- A lawlib explorer with jurisdiction/authority filters, eleven actual rules,
  three authorities, readable `.oath` source and compiled JSON, provenance, case usage, and local bookmarks.
- Five historical case workspaces with proof steps, input-removal dependency
  demonstrations, attributed facts, Rust reports, downloads, and CLI commands.
- Eleven documentation pages including the language specification, Python/CLI APIs,
  oracle dependence, trust boundaries, training, and Seattle coverage plans.
- An Oathkeeper and Rust source browser with exact implementation text, symbol search, downloads,
  and shareable line links.
- Three source snapshots with real browser SHA-256 checks against the source lock.

Hash routes allow direct links and refresh on static hosting. Bookmarks remain
in the browser; there is no user account or legal-case backend.

Baseline proof bundles and reports were generated using the Rust 0.3 checker.
The interactive page visualizes fixed dependency graphs; it does not run the
Rust verifier in the browser or provide a general online legal decision engine.
The application preserves the module's August 2021 legal snapshot and outstanding
independent-review status.

The application also exposes the typed vocabulary, federal/state/city authoring
modules, parser/compiler, kernel signature checks, and pending oracle reassessment.
The source archive is version 0.3 and replays the same native proof fingerprint
when extracted into a different directory. `scripts/sync-lawlib.py` in the site
checkout refreshes artifacts from the actual native compiler and verifier.
