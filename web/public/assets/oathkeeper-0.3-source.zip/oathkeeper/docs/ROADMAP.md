# Roadmap

## 0.1 — executable foundation (implemented)

- Open TOML/JSON ground proof language and Rust verifier.
- Explicit positive/negative claims and ordered rule applications.
- Jurisdiction applicability DAG and bitemporal rule snapshots.
- Frozen probabilistic oracle outputs and request-bound provider agreements.
- Dependency reports, bundle fingerprints, normalized oracle-count score.
- CLI, native Python bindings, fictional US/HOA example, fixed-context RL example.
- Tests, CI, Apache license, and legal library contribution protocol.

## 0.2 — real law and scoped precedent (implemented)

- Reusable law modules and separate case files; typed symbol/integer parameters.
- Explicit ground substitutions and checked integer comparisons.
- Authorities, holding/text roles, explicit scope premises, forum/time assessments,
  and treatment/review status in dependency reports.
- Sourced fact classifications separating record facts, judicial findings, and
  scope assumptions.
- Seattle Ordinance 120573, Long, and Timbs: nine rules and five historical proofs.
- Pinned source snapshots, representation-aware replay, source auditing, and
  explicit incomplete coverage inventory.

## 0.3 — readable source and checked signatures (implemented)

- Declarative `.oath` parser/compiler over the independently checked Rust IR.
- Nominal domain types, predicate signatures, arity checks, and declared constants.
- Transitive content-pinned imports, collision/cycle checks, and source maps.
- Federal, Washington, and Seattle modules; five migrated historical proofs.
- Explicit ordinary-branch conditions and the real authorized-vehicle exclusion.
- Pending oracle reassessment over Long's actual record, without fabricated outputs.
- Comparison of supplied counterarguments under identical context, and richer
  assumption reports. No automatic conflict resolution or global consistency claim.
- Independent legal and formalization reviews remain pending.

## Next — language and provenance

- Richer typed terms, dates, quantities, parties, and quantified reasoning.
- Package registry/distribution on top of local content-pinned imports.
- Cross-implementation canonical serialization and signed oracle attestations.
- Authenticated evidence ingestion, source-byte verification, and replay tools.
- Resource limits and stable structured error codes for hosted evaluation.
- Proof search outside the kernel, editor integration, and conservative definitions
  plus checked reusable lemmas.

## Legal library

- Establish legal and formalization review with immutable provenance.
- Add a small, reviewed US module before scaling a shared definitions library.
- Represent exceptions, preemption, burdens, and disputed interpretations with
  explicit semantics and independently tested proof rules.
- Add counterproof/consistency analysis, authority relations, and case-law models.
- Introduce other legal systems with contributors competent in those systems;
  encode cross-border choice of law explicitly.

## Training and institutional use

- Curate immutable proof tasks with audited assumptions and leakage controls.
- Evaluate adversarial proof generation and oracle dependence separately.
- Research calibrated uncertainty without treating confidence as a theorem.
- Explore court pilots only with agreed corpus, authenticated oracle procedures,
  procedural safeguards, contestability, and qualified institutional partners.

These are goals, not claims of implemented functionality or court readiness.
