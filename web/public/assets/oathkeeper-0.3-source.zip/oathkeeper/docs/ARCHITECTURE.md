# Architecture

The trusted kernel is deliberately smaller than the eventual legal authoring
system. It verifies explicit derivations; search, natural-language extraction,
model calls, and legal interpretation stay outside it.

```mermaid
flowchart LR
    Sources[Versioned legal sources] --> Review[Legal review and formalization]
    Review --> Source[Typed .oath declarations]
    Source --> Compiler[Rust compiler and pinned imports]
    Compiler --> Library[Explicit typed lawlib IR]
    Humans[Agreed humans / classifiers] --> Attest[Recorded oracle attestations]
    Facts[Case facts and evidence references] --> Bundle[Versioned proof bundle]
    Library --> Bundle
    Attest --> Bundle
    Policy[Agreed oracle policy] --> Bundle
    Prover[Human / LLM proof author] --> Bundle
    Bundle --> Kernel[Rust deterministic kernel]
    Kernel --> Report[Dependencies, digest, verifiability]
    Report --> Python[Python / RL evaluator / audit tools]
```

| Component | Current responsibility |
| --- | --- |
| `oathkeeper-core` | Versioned typed IR, .oath compilation with source maps and pinned imports, compatibility parsing, jurisdiction resolution, snapshot time eligibility, proof checking, dependency tracking, scoring |
| `oathkeeper-cli` | Local verification and checked JSON normalization; exit status for automation |
| `oathkeeper-python` | PyO3 native extension using exactly the same Rust verifier; JSON reports and Python exceptions |
| `lawlib` | Real Seattle ordinance/precedent module, five historical case proofs, source locks, coverage inventory, and review policy; independent review remains outstanding |
| `examples` | Fictional executable case, source/evidence bytes, and fixed-context RL evaluator |

## Trust boundaries

The derivation checker cannot establish that supplied laws mean what their authors
say they mean. Reviewers must establish source authenticity, faithful
formalization, temporal validity, and applicable jurisdiction. Facts and oracle
agreements are trusted inputs. Provenance hashes identify bytes but do not
authenticate them. v0.1 accepts self-declared provider identities; a production
ingestion layer must verify authenticated attestations before constructing a
trusted bundle.

There is no claim that a proof excludes all alternative legal arguments. The
system supports reproducible, assumption-visible arguments. It does not decide
which of competing interpretations a court should accept. A court-oriented
deployment would need a procedural agreement defining the corpus, jurisdiction,
burdens of proof, oracle protocol, challenges, and admissibility.

Subjective functions must be replayable as frozen outputs. A live API request is
not part of verification. Providers can change; versions and evidence references
make a change visible in the bundle fingerprint. Confidence is distinct from
proof status and distinct from the oracle-count score. No unjustified probability
composition is built into the kernel.

## Evolution

Language 0.2 adds typed symbol/integer terms, parameterized rules, exact ground
substitutions, checked integer comparisons, and source-backed authority records.
Holding scope must occur as an explicit premise. An authority assessment is
trusted input scoped to a specific rule, forum, and legal instant; the latest
visible recording controls and negative treatment blocks use. The kernel checks
these declarations, not their legal correctness. The source auditor verifies
local source snapshots outside the kernel. See [SPEC-0.2.md](SPEC-0.2.md).

Version 0.3 implements a thin surface language with nominal domain types, predicate
signatures, exact declarations and derivations, transitive pinned imports, and source
maps. The kernel checks types on direct JSON as well as compiled sources. See
[SPEC-0.3.md](SPEC-0.3.md).

A future extension may offer events, dates, monetary values, quantifiers, and tactics. Its elaborator should emit explicit proof terms checked
by a versioned kernel. New primitives need a written semantics and adversarial
tests. A richer logic could support defeasibility, competing holdings, modalities,
burdens, and temporal obligations; treating those as opaque proposition names is
the current prototype's intentional limit.

International support should reuse the graph and timestamps while allowing
different source categories and authority relationships. Country names,
government levels, and US supremacy assumptions are not hardcoded. Cross-border
choice of law needs explicit legal rules; merely adding multiple parents does
not resolve a conflict of laws.

Time remains a pinned-snapshot model: effective intervals and recording cutoffs,
not a transaction-time correction store or separate conduct/adjudication clocks.
`compare_arguments` identifies two checked opposing arguments in an identical
context; it does not search the corpus or prioritize binding over persuasive law.
