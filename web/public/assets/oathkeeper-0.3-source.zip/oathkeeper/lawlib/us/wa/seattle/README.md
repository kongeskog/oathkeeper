# Seattle law library

This is the first **real-authority** module in Oathkeeper. It contains eleven
parameterized rules derived from Seattle Ordinance 120573, *City of Seattle v.
Long*, and *Timbs v. Indiana*, plus five executable reconstructions of issues in
the actual Long record. It is a machine-assisted formalization awaiting separate
legal and formal review, not a complete or current Seattle law certification.

```sh
cargo run -- compile lawlib/us/wa/seattle/parking.oath
cargo run -- verify lawlib/us/wa/seattle/cases/long-excessive-fines.case.oath
python tools/audit_lawlib.py
```

The shared [module](parking.oath) is independent of the individual case
files. A case supplies evidence, its query, and its proof; it cannot redefine
the library's rules or authority assessments. Each rule includes parameters,
source digest, pinpoint, holding/text role, and an explicit scope premise.

## Sources and historical scope

| Authority | Encoded material | Source |
| --- | --- | --- |
| Seattle Ordinance 120573 § 1, SMC 11.72.440 | Explicit ordinary 72-hour conditions, authorized-vehicle exclusion, and the impoundment framework | [City Clerk scan](https://clerk.seattle.gov/~archives/Ordinances/Ord_120573.pdf) |
| *City of Seattle v. Long*, 198 Wn.2d 136, 493 P.3d 94 (2021), No. 98824-2 | Selected majority holdings about fines, ability to pay, and homestead protections | [Court slip opinion](https://www.courts.wa.gov/opinions/pdf/988242.pdf), [opinion-text mirror](https://law.justia.com/cases/washington/supreme-court/2021/98824-2.html) |
| *Timbs v. Indiana*, 586 U.S. 146 (2019), No. 17-1091 | Incorporation of the Excessive Fines Clause | [Supreme Court PDF](https://www.supremecourt.gov/opinions/18pdf/17-1091_5536.pdf) |

The legal snapshot is **August 13, 2021, 00:00 UTC**, following Long's filing on
August 12 at 08:00 Pacific. Recording/ingestion timestamps are in October 2026.
This separation is intentional: a source downloaded today can support a
historical reconstruction, but the formalizer must not backdate its ingestion.

The ordinance signature page (scan PDF p. 4) shows passage October 22, approval
October 29, and filing October 30, 2001. Section 2 specifies thirty days after
approval; the modeled commencement is November 28, 2001, at Seattle local midnight.
The Timbs decision timestamp is normalized to midnight UTC on its stated decision
date; no exact release time is asserted. These are explicit modeling conventions.

The court-hosted Long PDF states that the slip text was revised for official
publication. Our pinned Long evidence is the original judicial text extracted
from the mirror's `noframes` element, with whitespace normalized. It is **not**
represented as the revised official reporter text or as the bytes of the court
PDF. The court PDF was consulted during research; direct executor downloading
was blocked. Editorial summaries and website markup are excluded from the
committed text. The separate concurrence remains labeled and is not encoded as
a majority holding. Reconciliation against the final official text is a review
task, explicitly outstanding.

[sources.lock.json](sources.lock.json) records exact snapshot hashes, retrieval
URLs, official URLs, transformations, and source status. The ordinance scan and
Timbs PDF are pinned original PDF bytes. `tools/audit_lawlib.py` verifies those
bytes and every source reference before running all listed proofs. A separate
replay tool reproduces downloads into a new directory and rejects changed bytes:

```sh
python tools/refetch_sources.py lawlib/us/wa/seattle/sources.lock.json /tmp/oathkeeper-source-replay
```

## What the proofs establish

| Case file | Checked result and limits |
| --- | --- |
| `long-statutory-framework.case.oath` | An established SMC violation is subject to Chapter 11.30's impoundment framework. This does not prove satisfaction of every procedural or constitutional prerequisite. |
| `long-excessive-fines.case.oath` | Reconstructs the majority's excessive-fines result using the actual recorded gross-disproportionality judgment, rather than inventing a numeric test. |
| `long-ability-to-pay.case.oath` | Reconstructs Long's requirement to consider ability to pay in its excessiveness analysis. This is not attributed to Timbs as an independent nationwide holding. |
| `long-homestead.case.oath` | Long's occupied-personal-property situation does not require an additional homestead declaration. It does not establish a universal exemption from impoundment. |
| `long-no-automatic-impoundment-bar.case.oath` | Reconstructs the majority's distinction between homestead protection at debt enforcement and independent parking impoundment authority. It does not endorse an unconstitutional tow. |

The ordinary 72-hour rule is reusable but is not used to reconstruct Long's exact
parking duration from incomplete timing evidence. The historical proofs instead
use the violation reported as established in the case. The ordinary-branch version 2 rule
requires historical scope and location, whole-hour duration, and a checked
comparison. Each of these exclusions/qualifications is a separate negative
premise: a shorter posted limit, other legal provision, subsection C exclusion,
junk motor vehicle, and abandoned junk motor vehicle.

Two new rules formalize subsection C from the actual ordinance scan, page 3,
lines 37–38. A matter/vehicle relation, municipal location, and authorization
establish `parking.smc72_c_excluded(matter)`; that exclusion establishes the
negative of a violation of this section. The `Vehicle` type cannot be used where
a `Matter` is expected. No premise is supplied by silence. Tests exercise this
actual legal branch with explicitly synthetic boundary inputs, separate from
the five historical case reconstructions.

Exactly 72 hours does not satisfy the strict comparison. Whole-hour integer
duration is a restricted representation; fractional durations require a finer
time unit in a future rule version. Other shorter-limit and junk-vehicle branches and definitions must be added
separately. A scope assertion is not inferred from silence or from a favorable
classification label.

## Court findings, oracle dependence, and future cases

Every historical fact has a source, pinpoint, explanation, and basis kind:
`record_fact`, `judicial_finding`, or `scope_assumption`. The current five case
files use reported record facts and judicial findings. They do not fabricate
classifier outputs, human agreements, or confidence values for a real court.

In particular, the excessive-fines proof assumes the majority's recorded
gross-disproportionality finding. Its oracle-count score is therefore 1.0, while
the report exposes that judicial finding and the unreviewed authority assessments.
That score says there are no additional oracle attestations in this reconstruction;
it does not mean a subjective legal judgment has become a mathematical fact.
This is a proof of a derivation from a recorded judgment, not an independent
automated decision of the merits.

For a new case, bind `matter` to its own stable ID, supply actual evidence,
establish each scope condition, and obtain a justified disproportionality judgment
through the agreed oracle protocol when necessary. No original Long finding
automatically transfers to that person. New legal times/forums require new
authority assessments. Reports distinguish binding/persuasive assessments and
machine-assisted/unreviewed versus reviewed inputs; the kernel does not certify
the assessments themselves.

## Coverage and expansion

[coverage.json](coverage.json) lists exactly what exists and what is missing.
The full Seattle inventory is incomplete, so no invented coverage percentage is
reported. The approach to citywide coverage is in
[SEATTLE_PLAN.md](../../../../docs/SEATTLE_PLAN.md). The current logic still
needs extension for many legal constructs; this module does not imply every
Seattle provision can already be expressed faithfully.

Code and formalizations use the repository license. Source artifacts retain their
own legal status; the code license does not relicense archival attachments or
third-party material. See the rights notes in the source lock.

## Authoring, imports, and pending review

The `.oath` sources are canonical for version 0.3. Seattle imports
[Washington precedent](../long.oath), which imports [federal precedent](../../timbs.oath),
which imports the shared [typed vocabulary](../../../vocabulary.oath). Every
import pins exact bytes. Availability through import does not establish legal
applicability or priority. `oath.lock.json` pins the flattened module and complete
source graph; `sources.lock.json` separately pins the primary authorities.

The old `parking.module.json` and `.case.json` files are retained as 0.2 regression
fixtures. Tests compare the five migrated proofs' goals, dependency identities,
authority records, and fact provenance against those fixtures.

[long-oracle-reassessment.case.oath](cases/long-oracle-reassessment.case.oath)
is a pending application over the actual Long record. It removes the sourced
final disproportionality finding and requires an agreed oracle response. The
provider ID is explicitly a pending protocol placeholder, not a real approval.
No attestation or confidence output is invented; verification reports
`E_MISSING_EVIDENCE`. The source auditor checks that this case stays pending.

[review.json](review.json) separately records legal and formalization review as
pending. Visual checking of the pinned subsection C text and passing compiler
checks do not satisfy independent review. Authority assessments remain
`machine_assisted_unreviewed`.
