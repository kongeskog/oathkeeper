# Oathkeeper

**An open language and Rust kernel for verifiable legal proofs.**

Oathkeeper makes legal reasoning inspectable and machine-checkable, with the
long-term role that Lean and mathlib play in mathematics. Proofs establish what
follows from a supplied formalization, facts, and agreed oracle outputs.
Subjective judgments and legal interpretation remain visible assumptions.

The **0.3 research prototype** includes a readable `.oath` language, a compiler
with content-pinned imports, a deterministic Rust checker, CLI, and native Python
bindings. The [Seattle lawlib](lawlib/us/wa/seattle/README.md) contains eleven
source-backed rules and five executable reconstructions of an actual court case.
Independent legal and formalization reviews remain pending.

```sh
# Compile the federal → Washington → Seattle source graph into explicit JSON IR.
cargo run -- compile lawlib/us/wa/seattle/parking.oath
# Verify a real historical proof through the Rust kernel.
cargo run -- verify lawlib/us/wa/seattle/cases/long-excessive-fines.case.oath
# Export a checked bundle for Python/RL tools.
cargo run -- normalize lawlib/us/wa/seattle/cases/long-excessive-fines.case.oath > /tmp/long.json
python tools/audit_lawlib.py
cargo test --workspace --locked
```

Read [the actual Seattle source](lawlib/us/wa/seattle/parking.oath),
[Washington precedent](lawlib/us/wa/long.oath),
[federal precedent](lawlib/us/timbs.oath), and
[the historical proof](lawlib/us/wa/seattle/cases/long-excessive-fines.case.oath).
The complete authoring grammar and semantics are in [SPEC-0.3](docs/SPEC-0.3.md).

A proof step from the Long reconstruction:

```oath
step violation: constitutional.excessive_fines_violation(long.98824-2)
  by apply wa.long.gross-disproportionality @ "1"(matter = long.98824-2)
  using [federal-scope, fine, disproportionality-finding];
```

Types such as `Matter` and `Vehicle`, predicate signatures, exact substitutions,
and explicit premises are checked by the Rust kernel on both `.oath` and direct
JSON input. The compiler provides source locations, import locks, and readable
declarations. It does not add a second way to bypass proof checking. Python
provides integration; JSON remains the machine interchange format.

## Real law, scope, and review

The corpus formalizes selected holdings of *City of Seattle v. Long* (Washington
Supreme Court, 2021), *Timbs v. Indiana* (2019), and SMC 11.72.440 from Seattle
Ordinance 120573. Its legal snapshot is August 13, 2021. The ordinary 72-hour
branch requires explicit evidence about its qualifications. Subsection C's
authorized-vehicle exclusion is modeled separately. Exactly 72 hours does not
satisfy the strict greater-than condition.

Historical proofs preserve the court's recorded findings as sourced inputs.
The [oracle reassessment](lawlib/us/wa/seattle/cases/long-oracle-reassessment.case.oath)
removes the court's gross-disproportionality finding and awaits an agreed
attestation. Verification intentionally reports missing evidence. No classifier
probability or human approval is fabricated for that real case.

Missing information never proves a negative exception. Separately supported
opposite arguments can be checked with `compare-arguments`; the result exposes
a conflict without selecting a legal winner. The coverage inventory is explicitly
incomplete. See [the Seattle coverage plan](docs/SEATTLE_PLAN.md).

## Versions, jurisdictions, and oracles

Rules carry versions, effective intervals, recording timestamps, citations, and
source digests. Queries select legal time, knowledge cutoff, and forum. Imports
pin exact bytes; jurisdiction ancestry determines applicability separately.
An HOA is a private covenant context, not a sovereign level. Geographic depth
never supplies an implicit preemption or override rule.

An oracle runs outside the kernel, through an agreed human or classifier
protocol. A frozen attestation binds the proposition, question, provider/version,
confidence, evidence digest, and recording time. Version 0.3 accepts at most one
frozen response per request; aggregation or disagreement must be resolved by the
host's protocol. Missing or abstaining responses cannot supply a proof premise.

The normalized score is **`1/(1+N)`**, where `N` counts distinct used attestation
IDs. Reports also expose source facts, judicial findings, scope assumptions,
oracle requests, and unreviewed authority assessments. The score measures its
declared oracle count, not legal correctness, truth, coverage, or confidence.
Bundling questions or relabeling judgments can game it. RL environments must
freeze the context and reward valid derivations, with this score as a diagnostic.

## Python

```sh
python -m venv .venv
. .venv/bin/activate
pip install 'maturin>=1.7,<2'
maturin develop
python -m unittest discover -s python/tests
```

```python
import json
import oathkeeper

path = "lawlib/us/wa/seattle/cases/long-excessive-fines.case.oath"
compiled = json.loads(oathkeeper.compile_file(path))
report = json.loads(oathkeeper.verify_file(path))
print(report["goal"], report["judicial_finding_count"])
# Direct JSON: oathkeeper.verify(bundle_json, "json"). Invalid input raises ValueError.
```

Python requires 3.10+ and uses the same native Rust kernel. The legacy
`verify(text, format)`, `verify_case(module_json, case_json)`, and TOML/JSON 0.1/0.2
interfaces remain supported. `examples/hoa.oath` is the explicitly fictional
legacy oracle tutorial, not part of the real Seattle corpus.

The checker performs no network/model calls or evidence-file reads. The separate
auditor checks pinned source bytes. Neither hashes nor a successful derivation
authenticate inputs or prove that an English legal passage was translated
faithfully. The logic currently checks conditional arguments; general defeasible
reasoning, burdens, quantified theorems, and comprehensive legal history remain
future work. Court use would require independent review and agreed procedures.

- [0.3 specification](docs/SPEC-0.3.md) · [0.2](docs/SPEC-0.2.md) · [0.1](docs/SPEC.md)
- [Architecture](docs/ARCHITECTURE.md) · [RL evaluation](docs/TRAINING.md)
- [Lawlib review process](lawlib/README.md) · [Roadmap](docs/ROADMAP.md)
- [Contributing](CONTRIBUTING.md)

Licensed under [Apache 2.0](LICENSE). Source artifacts retain their documented
legal status. No network service or account is required.
